
def publish_article(title, content, cover):
    print("发布成功:", title)
