
from agents.base_agent import ask_llm

def run_analyst():
    print(ask_llm("阅读量3000点赞100，给优化建议"))
