
from agents.base_agent import ask_llm
from memory import memory

def run_planner():
    prompt = "生成今天AI自动化领域的选题、目标用户和大纲"
    result = ask_llm(prompt)
    memory.save("plan", result)
