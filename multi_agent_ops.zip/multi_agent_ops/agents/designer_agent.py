
from memory import memory
from tools.image_gen import generate_cover

def run_designer():
    plan = memory.get("plan")
    img_url = generate_cover(f"科技封面: {plan}")
    memory.save("cover", img_url)
