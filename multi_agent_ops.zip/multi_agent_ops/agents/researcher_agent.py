
from agents.base_agent import ask_llm
from memory import memory

def run_researcher():
    plan = memory.get("plan")
    result = ask_llm(f"根据选题做资料研究: {plan}")
    memory.save("research", result)
