
from agents.base_agent import ask_llm
from memory import memory

def run_writer():
    plan = memory.get("plan")
    research = memory.get("research")
    article = ask_llm(f"写文章:\n{plan}\n{research}")
    memory.save("article", article)
