
from memory import memory
from tools.cms_api import publish_article

def run_publisher():
    article = memory.get("article")
    cover = memory.get("cover")
    publish_article("AI Agent 自动化", article, cover)
