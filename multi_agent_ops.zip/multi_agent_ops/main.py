
from agents.planner_agent import run_planner
from agents.researcher_agent import run_researcher
from agents.writer_agent import run_writer
from agents.designer_agent import run_designer
from agents.publisher_agent import run_publisher
from agents.analyst_agent import run_analyst

def run_all():
    run_planner()
    run_researcher()
    run_writer()
    run_designer()
    run_publisher()
    run_analyst()

if __name__ == "__main__":
    run_all()
