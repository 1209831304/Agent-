
import os
from dotenv import load_dotenv
load_dotenv()

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")

MODEL_FAST = "gpt-4.1-mini"
MODEL_STRONG = "gpt-4.1"
MODEL_LONG = "gpt-4o"
